import os
import json
from dataclasses import dataclass, field
from typing import Any, List, Union

def normalize(arr, t_min, t_max):
    norm_arr = []
    diff = t_max - t_min
    diff_arr = max(arr) - min(arr)
    for i in arr:
        temp = (((i - min(arr))*diff)/diff_arr) + t_min
        norm_arr.append(temp)
    return norm_arr

reference = {}

inp = open("/mnt/e/Zero-Shot/Dataset/CIRR/cirr/captions/cap.rc2.val.json", "r")
data = json.load(inp)
inp.close()

for i in range(len(data)):
   reference[str(data[i]["pairid"])] = data[i]["reference"]

inp = open("CIRR-Top.json", "r")
data = json.load(inp)
inp.close()

alpha = 0.9
beta = 0.15
threshold = 0.45

top_data = {}

for i in range(len(data)):
    tmp = [] 
    arr = []
    for j in range(len(data[i]["matches"])):
        if data[i]["matches"][j]["score"] < threshold:
            break
        tmp.append([data[i]["matches"][j]["score"], 1, data[i]["matches"][j]["id"]])
        arr.append(data[i]["matches"][j]["score"])

    if len(arr) > 0:
        if max(arr) == min(arr):
            arr = [1 for _ in range(len(arr))]
        else:
            arr = normalize(arr, 0, 1)

    for j in range(len(arr)):
        tmp[j][0] = arr[j] * (1 - alpha)

    top_data[data[i]["query_image"]] = tmp   

inp = open("CIRR-Bot.json", "r")
data = json.load(inp)
inp.close()

merged_data = {}

for pairid in data.keys():
    tmp = [] 
    arr = []

    assert str(pairid) + ".jpg" in top_data
 
    for j in range(len(data[pairid])):
        tmp.append([data[pairid][j][1], 0, data[pairid][j][0]])
        arr.append(data[pairid][j][1])

    arr = normalize(arr, 0, 1)
    for j in range(len(arr)):
        tmp[j][0] = arr[j] * alpha

    tdata = top_data[str(pairid) + ".jpg"]
    
    mdata = {}

    for j in range(len(tmp)):
        mdata[tmp[j][2]] = tmp[j][0]

    for j in range(len(tdata)):
        if tdata[j][2] in mdata:
            mdata[tdata[j][2]] = tdata[j][0] + mdata[tdata[j][2]] + beta
        else:
            mdata[tdata[j][2]] = tdata[j][0]
        
    arr = []
    for id in mdata.keys():
        arr.append((id, mdata[id]))

    arr.sort(key = lambda x: x[1], reverse = True)
    merged_data[pairid] = arr

out = open("CIRR-merged.json", "w")
json.dump(merged_data, out)
out.close()


