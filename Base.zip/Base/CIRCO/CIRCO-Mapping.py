import os
import json
from dataclasses import dataclass, field
from typing import Any, List, Union

idx = {} 
inp = open("/mnt/e/Zero-Shot/Dataset/CIRCO/annotations/val.json", "r")
data = json.load(inp)
inp.close()

for i in range(len(data)):
    idx[str(data[i]["reference_img_id"]) + ".jpg"] = i

assert len(idx.keys()) == 220

inp = open("CIRCO-Ret.json", "r")
data = json.load(inp)
inp.close()

chk = {}

for i in range(len(data)):
    chk[idx[data[i]["query_image"]]] = 1
    data[i]["query_image"] = str(idx[data[i]["query_image"]]) + ".jpg"

assert len(chk.keys()) == 220

out = open("CIRCO-Top.json", "w")
json.dump(data, out, indent = 4)
out.close()