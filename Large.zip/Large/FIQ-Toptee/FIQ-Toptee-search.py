import os
import json
from dataclasses import dataclass, field
from typing import Any, List, Union

@dataclass
class QueryExample: 
    target_iid: Union[int, str, List[int], List[str], None] # can be int or 
    retrieved_iids: List[Union[int, str]] # ranked by score, can be str (cirr) or int (circo)

def normalize(arr, t_min, t_max):
    norm_arr = []
    diff = t_max - t_min
    diff_arr = max(arr) - min(arr)
    for i in arr:
        temp = (((i - min(arr))*diff)/diff_arr) + t_min
        norm_arr.append(temp)
    return norm_arr

ans = []

for alpha in [x / 100 for x in range(70, 100, 1)]:
    for beta in [x / 100 for x in range(0, 31, 5)]:
        for threshold in [x / 100 for x in range(45, 90, 5)]:
            inp = open("FIQ-Toptee-Top.json", "r")
            data = json.load(inp)
            inp.close()

            top_data = {}

            for i in range(len(data)):
                tmp = [] 
                arr = []
                for j in range(len(data[i]["matches"])):
                    if data[i]["matches"][j]["score"] < threshold:
                        break
                    tmp.append([data[i]["matches"][j]["score"], 1, data[i]["matches"][j]["id"]])
                    arr.append(data[i]["matches"][j]["score"])

                if len(arr) > 0:
                    if max(arr) == min(arr):
                        arr = [1 for _ in range(len(arr))]
                    else:
                        arr = normalize(arr, 0, 1)

                for j in range(len(arr)):
                    tmp[j][0] = arr[j] * (1 - alpha)

                top_data[data[i]["query_image"]] = tmp    

            inp = open("FIQ-Toptee-Bot.json", "r")
            data = json.load(inp)
            inp.close()

            merged_data = {}

            for pairid in data.keys():
                tmp = [] 
                arr = []

                assert str(pairid) + ".jpg" in top_data
 
                for j in range(50):
                    tmp.append([data[pairid][j][1], 0, data[pairid][j][0]])
                    arr.append(data[pairid][j][1])

                arr = normalize(arr, 0, 1)
                for j in range(len(arr)):
                    tmp[j][0] = arr[j] * alpha

                tdata = top_data[str(pairid) + ".jpg"]
    
                mdata = {}
                for j in range(len(tmp)):
                    mdata[tmp[j][2]] = tmp[j][0]

                for j in range(len(tdata)):
                    if tdata[j][2] in mdata:
                        mdata[tdata[j][2]] = tdata[j][0] + mdata[tdata[j][2]] + beta
                    else:
                        mdata[tdata[j][2]] = tdata[j][0]
        
                arr = []
                for id in mdata.keys():
                    arr.append((id, mdata[id]))

                arr.sort(key = lambda x: x[1], reverse = True)
                merged_data[pairid] = arr

            k_range = [1, 5, 10, 50]
            ret_dict = {k: [] for k in k_range}

            target = {} 
            inp = open("/mnt/e/Zero-Shot/Dataset/scenic/magiclens/data/fiq/captions/cap.toptee.val.json", "r")
            data = json.load(inp)
            inp.close()

            for i in range(len(data)):
                target[str(i)] = data[i]["target"]

            query_examples = []

            for pairid in merged_data.keys():
                target_iid = [target[pairid]]
    
                retrieved_iids = []
                for j in range(len(merged_data[pairid])):
                    retrieved_iids.append(merged_data[pairid][j][0])

                query_examples.append(QueryExample(target_iid = target_iid, retrieved_iids = retrieved_iids))
        
            for q_example in query_examples:
                assert len(q_example.retrieved_iids) > 0, "retrieved_iids is empty"
                for k in k_range:
                    recalled = False
                    if isinstance(q_example.target_iid, list):
                        for one_target_iid in q_example.target_iid:
                            if one_target_iid in q_example.retrieved_iids[:k]:
                                recalled = True
                    elif isinstance(q_example.target_iid, int) or isinstance(q_example.target_iid, str):
                        if q_example.target_iid in q_example.retrieved_iids[:k]:
                            recalled = True
                    else:
                        raise ValueError(f"target_iid is of type {type(q_example.target_iid)}")

                    if recalled:
                        ret_dict[k].append(1)
                    else:
                        ret_dict[k].append(0)

            # calculation
            total_ex = len(query_examples)
            ret_dict = {k: (sum(v) / total_ex) * 100 for k, v in ret_dict.items()}
            print("Alpha: " + str(alpha) + ", Beta: " + str(beta) + ", Threshold: " + str(threshold) + ", Recalls: ", ret_dict)
            ans.append({"Alpha": alpha, "Beta" : beta, "Threshold" : threshold, "Recall": ret_dict})

out = open("data.json", "w")
json.dump(ans, out, indent = 4)
out.close()