import os
import json
from dataclasses import dataclass, field
from typing import Any, List, Union
import statistics
import torch
import numpy as np

gt_img_ids = {} 
reference = {}
inp = open("/mnt/e/Zero-Shot/Dataset/CIRCO/annotations/val.json", "r")
data = json.load(inp)
inp.close()

for i in range(len(data)):
    reference[data[i]["id"]] = data[i]["reference_img_id"]
    gt_img_ids[data[i]["id"]] = data[i]["gt_img_ids"]

inp = open("CIRCO-Merged.json", "r")
data = json.load(inp)
inp.close()

ap_at5 = []
ap_at10 = []
ap_at25 = []
ap_at50 = []

queries = []
for id in data.keys():
    gt_ids = gt_img_ids[int(id)]
    r_ids = reference[int(id)]   

    re_ids = []
    for j in range(len(data[id])):
        re_ids.append(data[id][j][0])

    queries.append((r_ids, gt_ids, re_ids))

for r_ids, gt_ids, re_ids in queries:  
    map_labels = torch.tensor(np.isin(re_ids, gt_ids), dtype=torch.uint8)
    precisions = torch.cumsum(map_labels, dim=0) * map_labels  # Consider only positions corresponding to GTs
    precisions = precisions / torch.arange(1, map_labels.shape[0] + 1)  # Compute precision for each position
    ap_at5.append(float(torch.sum(precisions[:5]) / min(len(gt_ids), 5)))
    ap_at10.append(float(torch.sum(precisions[:10]) / min(len(gt_ids), 10)))
    ap_at25.append(float(torch.sum(precisions[:25]) / min(len(gt_ids), 25)))
    ap_at50.append(float(torch.sum(precisions[:50]) / min(len(gt_ids), 50)))

    if float(torch.sum(precisions[:5]) / min(len(gt_ids), 5)) >= 0.4:
        print(r_ids, ' ', gt_ids)

print("mAP_at_5: ", statistics.mean(ap_at5) * 100)
print("mAP_at_10: ", statistics.mean(ap_at10) * 100)
print("mAP_at_25: ", statistics.mean(ap_at25) * 100)
print("mAP_at_50: ", statistics.mean(ap_at50) * 100)