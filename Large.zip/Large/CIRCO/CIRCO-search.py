import os
import json
from dataclasses import dataclass, field
from typing import Any, List, Union
import statistics
import torch
import numpy as np

@dataclass
class QueryExample: 
    target_iid: Union[int, str, List[int], List[str], None] # can be int or 
    retrieved_iids: List[Union[int, str]] # ranked by score, can be str (cirr) or int (circo)

def normalize(arr, t_min, t_max):
    norm_arr = []
    diff = t_max - t_min
    diff_arr = max(arr) - min(arr)
    for i in arr:
        temp = (((i - min(arr))*diff)/diff_arr) + t_min
        norm_arr.append(temp)
    return norm_arr

ans = []

for alpha in [x / 100 for x in range(70, 100, 1)]:
    for beta in [x / 100 for x in range(0, 31, 5)]:
        for threshold in [x / 100 for x in range(45, 90, 5)]:
            inp = open("CIRCO-Top.json", "r")
            data = json.load(inp)
            inp.close()

            top_data = {}

            for i in range(len(data)):
                tmp = [] 
                arr = []

                for j in range(len(data[i]["matches"])):
                    if data[i]["matches"][j]["score"] < threshold:
                        break
                    tmp.append([data[i]["matches"][j]["score"], 1, int(data[i]["matches"][j]["id"])])
                    arr.append(data[i]["matches"][j]["score"])

                if len(arr) > 0:
                    if max(arr) == min(arr):
                        arr = [1 for _ in range(len(arr))]
                    else:
                        arr = normalize(arr, 0, 1)

                for j in range(len(arr)):
                    tmp[j][0] = arr[j] * (1 - alpha)

                top_data[data[i]["query_image"]] = tmp  

            inp = open("CIRCO-Bot.json", "r")
            data = json.load(inp)
            inp.close()

            merged_data = {}

            for pairid in data.keys():
                tmp = [] 
                arr = []

                assert str(pairid) + ".jpg" in top_data
 
                for j in range(50):
                    tmp.append([data[pairid][j][1], 0, int(data[pairid][j][0])])
                    arr.append(data[pairid][j][1])

                arr = normalize(arr, 0, 1)
                for j in range(len(arr)):
                    tmp[j][0] = arr[j] * alpha

                tdata = top_data[str(pairid) + ".jpg"]
    
                mdata = {}
                for j in range(len(tmp)):
                    mdata[tmp[j][2]] = tmp[j][0]

                for j in range(len(tdata)):
                    if tdata[j][2] in mdata:
                        mdata[tdata[j][2]] = tdata[j][0] + mdata[tdata[j][2]] + beta
                    else:
                        mdata[tdata[j][2]] = tdata[j][0]
        
                arr = []
                for id in mdata.keys():
                    arr.append((id, mdata[id]))

                arr.sort(key = lambda x: x[1], reverse = True)
                merged_data[pairid] = arr

            gt_img_ids = {} 
            inp = open("/mnt/e/Zero-Shot/Dataset/CIRCO/annotations/val.json", "r")
            data = json.load(inp)
            inp.close()

            for i in range(len(data)):
                gt_img_ids[data[i]["id"]] = data[i]["gt_img_ids"]

            queries = []
            ap_at5 = []
            ap_at10 = []
            ap_at25 = []
            ap_at50 = []

            for id in merged_data.keys():
                assert int(id) in gt_img_ids
                gt_ids = gt_img_ids[int(id)]
    
                re_ids = []
                for j in range(len(merged_data[id])):
                    re_ids.append(merged_data[id][j][0])

                queries.append((gt_ids, re_ids))
          
            for gt_ids, re_ids in queries: 
                map_labels = torch.tensor(np.isin(re_ids, gt_ids), dtype=torch.uint8)
                precisions = torch.cumsum(map_labels, dim=0) * map_labels  # Consider only positions corresponding to GTs
                precisions = precisions / torch.arange(1, map_labels.shape[0] + 1)  # Compute precision for each position
                ap_at5.append(float(torch.sum(precisions[:5]) / min(len(gt_ids), 5)))
                ap_at10.append(float(torch.sum(precisions[:10]) / min(len(gt_ids), 10)))
                ap_at25.append(float(torch.sum(precisions[:25]) / min(len(gt_ids), 25)))
                ap_at50.append(float(torch.sum(precisions[:50]) / min(len(gt_ids), 50)))

            ret_dict = {}
            ret_dict["5"] = statistics.mean(ap_at5) * 100
            ret_dict["10"] = statistics.mean(ap_at10) * 100 
            ret_dict["25"] = statistics.mean(ap_at25) * 100
            ret_dict["50"] = statistics.mean(ap_at50) * 100
        
            print("Alpha: " + str(alpha) + ", Beta: " + str(beta) + ", Threshold: " + str(threshold) + ", mAPs: ", ret_dict)
            ans.append({"Alpha": alpha, "Beta" : beta, "Threshold" : threshold, "mAP": ret_dict})

out = open("data.json", "w")
json.dump(ans, out, indent = 4)
out.close()