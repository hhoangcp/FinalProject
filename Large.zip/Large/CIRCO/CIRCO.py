import os
import json
from dataclasses import dataclass, field
from typing import Any, List, Union

data_map = {}

inp =  open("data.json", "r")
data = json.load(inp)
inp.close()

for i in range(len(data)):
    data_map[(data[i]["Alpha"], data[i]["Beta"], data[i]["Threshold"])] = data[i]["mAP"]

arr = [[k[0], k[1], k[2], [data_map[k][x] for x in data_map[k].keys()]] for k in data_map.keys()]

arr = sorted(arr, key = lambda x: (x[3][3], x[3][2], x[3][1], x[3][0]), reverse = True)

data = []
for i in range(len(arr)):
    data.append({"Alpha" : arr[i][0], "Beta" : arr[i][1], "Threshold": arr[i][2], "mAP": arr[i][3]})

out = open("CIRCO.json", "w")
json.dump(data, out, indent = 4)
out.close()

    