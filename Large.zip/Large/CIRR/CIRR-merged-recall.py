import os
import json
from dataclasses import dataclass, field
from typing import Any, List, Union

k_range = [1, 5, 10, 50]
ret_dict = {k: [] for k in k_range}

target = {} 
reference = {}

inp = open("/mnt/e/Zero-Shot/Dataset/CIRR/cirr/captions/cap.rc2.val.json", "r")
data = json.load(inp)
inp.close()

for i in range(len(data)):
   reference[str(data[i]["pairid"])] = data[i]["reference"]
   target[str(data[i]["pairid"])] = data[i]["target_hard"]

inp = open("CIRR-Merged.json", "r")
data = json.load(inp)
inp.close()

@dataclass
class QueryExample: 
    reference_iid: Union[int, str, List[int], List[str], None] # can be int or
    target_iid: Union[int, str, List[int], List[str], None] # can be int or 
    retrieved_iids: List[Union[int, str]] # ranked by score, can be str (cirr) or int (circo)
    
query_examples = []

for pairid in data.keys():
    target_iid = [target[pairid]]
    reference_iid = reference[pairid]
    
    retrieved_iids = []
    for j in range(len(data[pairid])):
        retrieved_iids.append(data[pairid][j][0])

    while len(retrieved_iids) < 50:
        retrieved_iids.append(None)

    query_examples.append(QueryExample(reference_iid = reference_iid, target_iid = target_iid, retrieved_iids = retrieved_iids))

for q_example in query_examples:
    assert len(q_example.retrieved_iids) > 0, "retrieved_iids is empty"
    for k in k_range:
        recalled = False
        if isinstance(q_example.target_iid, list):
            for one_target_iid in q_example.target_iid:
                if one_target_iid in q_example.retrieved_iids[:k]:
                    recalled = True
        elif isinstance(q_example.target_iid, int) or isinstance(q_example.target_iid, str):
            if q_example.target_iid in q_example.retrieved_iids[:k]:
                recalled = True
        else:
            raise ValueError(f"target_iid is of type {type(q_example.target_iid)}")

        if recalled:
            ret_dict[k].append(1)
        else:
            ret_dict[k].append(0)

# calculation
total_ex = len(query_examples)
ret_dict = {k: (sum(v) / total_ex) * 100 for k, v in ret_dict.items()}
print("Recalls: ", ret_dict)